#' Ciekawa funkcja
#'
#' Jest to pierwsza funkcja stworzona przez Wojtka w tym programie, wtedy jeszcze uważał on,
#' że jest ona ciekawa
#' @param x An integer value
#' @usage ciekawafunkcja(x)
#' @export



ciekawafunkcja<-function(x) -x
