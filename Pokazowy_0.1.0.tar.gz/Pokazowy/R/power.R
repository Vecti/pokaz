#' @title  power
#'
#' @description  Jest to funkcja, która danego x podnosi do potęgi n
#' @param x An integer value( podstawa potegi)
#' @param n An integer value (wykladnik potegi)
#' @export
power<-function(x,n) x^n
